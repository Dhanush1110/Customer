package com.project.lodgeproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LodgeprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(LodgeprojectApplication.class, args);
	}

}
